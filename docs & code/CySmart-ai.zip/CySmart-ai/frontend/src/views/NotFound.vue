<template>
  <div class="min-h-[70vh] flex items-center justify-center flex-col text-center px-4">
    <div class="text-7xl font-bold text-primary mb-4">404</div>
    <h1 class="text-2xl font-semibold text-gray-900 mb-4">Page not found</h1>
    <p class="text-gray-600 mb-8">The page you visited does not exist or has been removed</p>
    <router-link to="/" class="btn btn-primary">
      Return to homepage
    </router-link>
  </div>
</template> 